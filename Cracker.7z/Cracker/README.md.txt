# Cracker

Cracker is a python code that crack md5 hashes by brute force approach.


## how to run it 

1)In the same folder path , create a file called "hashes.txt" .
  fill the file with the phone number pattern "05X-XXXXXXX" as a md5 encoded hash.

2)Wake up the minions - in this file we have 4 of them (we can use more) ,
  to wake up a minion , in the CLI press "py .\minion.py {minion port} //
  for example minion port = 10005 -> "py .\minion.py 10005" .

3)Run the master file - in the CLI press "py .\master.py".

## what to expect 
   As the cracker finish his work , you will find a text files with the cracked hashes
   who filled with the actual phone number , also you will get a printed dict 
   of all cracked hash .

## Good to know 	
   As we want to be able cracking every phone number , we will run on a huge chunk of numbers.
   therefore if you have a big hashes file(more then 10 hashes) you can split the chunk 
   for more minions(more minions == faster cracking), the split is dynamic , you just need to 
   update the MINIONS dict in the top of the master file .  

** there is hashes.txt file for example ** 

## License
   
	Bar Machluf 