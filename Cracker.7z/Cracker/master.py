#====[ Modules ]====#
import requests
import sys
import time

#====[ Consts ]====#
INPUT_FILE = "hashes.txt"
MAX_POSSIBILITIES = 99999999

#====[ Globals ]====#
MINIONS = [
    ('127.0.0.1', 10001),
    ('127.0.0.1', 10002),
    ('127.0.0.1', 10005),
    ('127.0.0.1', 10004)
]

#====[ Functions ]====#
def load_hashes_from_file(filename):
    """
    This function loads hashes from a file and returns a list of hashes.
    """
    with open(filename, 'r') as f:
        return [line.strip() for line in f.read().splitlines()]


def parse_response(response):
    """
    This function parses the response from the server and returns the data and error.
    """
    if response.status_code == 200:
        response_json = response.json()
        return response_json['data'], response_json['error']
    else:
        print("Weird error: %s" % response.text)
        return None, response.text


def stop_cracking_hash(hash):
    """
    This function stops cracking a hash by sending a stop request to every minion with the hash to stop cracking.
    """
    for minion in MINIONS:
        url = "http://%s:%d/stop/%s" % (minion[0], minion[1], hash)
        response = requests.get(url)
        if response.status_code != 200:
            print("Weird error: %s, url: %s" % (response.text, url))


def get_hash_status(hash):
    """
    This function returns the status of a hash on all minions.
    It checks each minion for the status of the specific hash.
    There are 4 optional statuses:
    1. "cracking" - the hash is being cracked
    2. "found" - the hash was found
    3. "not found" - the hash was not found, we will just keep on checking at the other minions cause another minion might have cracked it
    4. "missing" - the hash is missing on a minion, we'll rerun the crack on that minion
    If we got 4 "not found"s which means that the results list will be empty (hence we continue if a minion's status is "not found")
    we can surely say that the hash failed to crack on all minions.
    On the other hand, if we got "cracked" from one minion, we can stop the checking loop and return the crackes result, hance the return inside the loop.
    """
    results = []
    for index, minion in enumerate(MINIONS):
        url = "http://%s:%d/getstatus/%s" % (minion[0], minion[1], hash)
        try:
            response = requests.get(url)
            if response.status_code == 200:
                data, error = parse_response(response)
                if error is not None:
                    print("Error occured, %s" % error)
                    if error == "hash doesn't exist":
                        results.append(('missing', index))
                    else:
                        results.append(('error', None))
                    continue
                if data['status'] == "cracking":
                    results.append(('cracking', None))
                elif data['status'] == "not found":
                    continue
                elif data['status'] == "found":
                    results.append(('found', data['result']))
                    return results
                else:
                    results.append(('missing', index))
        except requests.exceptions.ConnectionError:
            print("Minion %d is not responding, skipping for now" % index)
            continue
    if len(results) == 0:
        results.append(('not found', None))

    return results


def crack_specific_hash(hash):
    """
    This function cracks the hash on multiple minions
    """
    for chunk in range(len(MINIONS)):
       crack_specific_chunk_for_hash(hash, chunk)


def crack_specific_chunk_for_hash(hash, chunk_num):
    """
    This function sends the crack request for the minion (determined by the chunk_num which is the minion index), with the chunk boundries (start and end)
    """
    chunk_size = int((MAX_POSSIBILITIES) / len(MINIONS))
    begin = chunk_num * chunk_size
    end = (chunk_num + 1) * chunk_size
    url = "http://%s:%d/crack/%s/%d/%d" % (MINIONS[chunk_num][0], MINIONS[chunk_num][1], hash, begin, end)
    response = requests.get(url)
    if response.status_code != 200:
        print("Weird error: %s, minion index: %d" % response.text, chunk_num)
        

def check_running_cracks():
    """
    This function checks if there are any running cracks on the minions.
    """
    active_cracks = set()
    for minion in MINIONS:
        url = "http://%s:%d/active_cracks" % (minion[0], minion[1])
        response = requests.get(url)
        if response.status_code != 200:
            print("Weird error: %s, url: %s" % (response.text, url))
        data, error = parse_response(response)
        if error is not None:
            print("Error occured, %s" % error)
        for hash in data:
            active_cracks.add(hash)
    return active_cracks


def is_alive(minion):
    """
    This function checks if a minion is alive.
    """
    url = "http://%s:%d/active_cracks" % (minion[0], minion[1])
    try:
        response = requests.get(url)
        if response.status_code != 200:
            print("Minion %s:%d is not functioning properly" % (minion[0], minion[1]))
            return False
        else:
            return True
    except requests.exceptions.ConnectionError:
        return False


def validate_minions():
    """
    This function checks if all minions are alive.
    """
    global MINIONS
    active_minions = []
    for minion in MINIONS:
        if is_alive(minion):
            active_minions.append(minion)
        else:
            print("Minion %s:%d is not running" % (minion[0], minion[1]))    
    MINIONS = active_minions



def main():
    global MINIONS
    # Check if all minions are alive
    validate_minions()
    if len(MINIONS) == 0:
        print("No active minions are available, exiting.")
        sys.exit(1)
    results = {}
    hashes = load_hashes_from_file(INPUT_FILE)
    ongoing_cracks = check_running_cracks()
    hashes_to_check = []
    # Check for each hash if it is already being cracked on the minions
    for hash in hashes:
        if hash not in ongoing_cracks:
            # if its not being cracked, add it to the list of hashes to check and run the crack on it
            print("Cracking hash %s" % hash)
            crack_specific_hash(hash)
        else:
            # if a crack for this hash is already running, we'll only check the status of the crack and won't rerun the crack
            print("Crack %s is already running" % hash)
        hashes_to_check.append(hash)
        

    while True:
        # Were checking the status of the hashes on the minions until we got a result for all of them
        # Every hash we crack we remove from the hashes_to_check list until it's empty
        for hash in hashes_to_check:
            minions_status = get_hash_status(hash)
            for status, result in minions_status:
                if status == "cracking":
                    continue
                elif status == "found":
                    print("Found hash %s with the result %s"%  (hash, result))
                    print("Stopping cracking hash %s on other minions" % hash)
                    stop_cracking_hash(hash)
                    hashes_to_check.pop(hashes_to_check.index(hash))
                    results[hash] = result
                    break
                elif status == "not found":
                    print("Hash %s failed to crack" % hash)
                elif status == "missing":
                    print("Hash %s is missing on minion %d. Rerunning crack" % (hash, result))
                    crack_specific_chunk_for_hash(hash, result)
        if len(hashes_to_check) == 0:
            break
        time.sleep(1)
    print("The crackes hashes are:")
    print(results)


if __name__ == "__main__":
    main()