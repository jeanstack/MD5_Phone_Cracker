#====[ Modules ]====#
from flask import Flask
from hashlib import md5

import multiprocessing
import sys

#====[ Consts ]====#
PHONE_PATTERN = "05%s-%s"
OPTIONS_LENGTH = 8


#====[ Globals ]====#
app = Flask(__name__)
ONGOING_CRACKS = {}

#====[ Functions ]====#
def create_response(data, error):
    """
    This function creates a response json to the master.
    """
    return {
        'data': data,
        'error': error
    }


def crack_hash(hash, begin, end):
    """
    This function cracks a hash.
    If it findes the hash, it creates a file with the hash as a file name and the content is the phone number that created that hash.
    """
    for i in range(begin, end):
        number = str(i)
        number = "0" * (OPTIONS_LENGTH - len(number)) + number
        number_hash = md5((PHONE_PATTERN % (number[0], number[1:])).encode()).hexdigest()
        print("Current: %s = %s : Expected %s" % (PHONE_PATTERN % (number[0], number[1:]), number_hash, hash))
        if number_hash == hash:
            with open('%s.txt' % hash, 'w') as f:
                f.write(PHONE_PATTERN % (number[0], number[1:]))
                break


@app.route('/active_cracks')
def active_cracks():
    """
    This function returns the active cracks.
    """
    return create_response(list(ONGOING_CRACKS), None)


@app.route('/stop/<hash>')
def stop_cracking(hash):
    """
    This function stops cracking a hash. It does this by removing the hash from the ONGOING_CRACKS dictionary and killing the subprocess that is cracking the hash.
    """
    if hash in ONGOING_CRACKS:
        ONGOING_CRACKS[hash].terminate()
        del ONGOING_CRACKS[hash]
        print("Stopped cracking hash %s" % hash)
        return create_response({
            'status': 'stopped'
            }, None)
    else:
        return create_response(None, 'Hash not found')
    

@app.route('/getstatus/<hash>')
def get_status(hash):
    """
    This function returns the status of a hash.
    If the process still exists that means that the crack if already running.
    If the process dies there are two options: 
    1. The process died because the hash was found.
    2. The process died because the hash was not found.
    We check if the hash cracked by checking if a new file was created with the hash as a file name.
    If the file exists we know that the hash was found and the result is it's content.
    If the file doesn't exist we know that the hash was not found.
    """
    global ONGOING_CRACKS
    if hash in ONGOING_CRACKS:
        if ONGOING_CRACKS[hash] is not None and ONGOING_CRACKS[hash].is_alive():
            return create_response({
                'status': 'cracking',
            }, None)
        else:
            try:
                with open('%s.txt' % hash, 'r') as f:
                    return create_response({
                        'status': 'found',
                        'result': f.read()
                    }, None)
            except FileNotFoundError:
                return create_response({
                    'status': 'not found'
                }, None)
            finally:
                ONGOING_CRACKS.pop(hash)
    else:
        return create_response(None, "hash doesn't exist")



@app.route('/crack/<hash>/<begin>/<end>')
def crack(hash, begin, end):
    """
    This function starts cracking a hash on a subprocess and saves the process object on the ONGOING_CRACKS dict.
    """
    p = multiprocessing.Process(target=crack_hash, args=(hash, int(begin), int(end)))
    p.start()
    ONGOING_CRACKS[hash] = p
    return {
        'status': 'cracking'
    }


def main(port):
    app.run(host='0.0.0.0', port=port, debug=True)


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("Usage: %s <port>" % sys.argv[0])
        sys.exit(1)
    main(sys.argv[1])
    


